# DG τ^10 exact 5→4 verification package

This repository is a self-contained verification package for the tenth-order
Ricci-flat parity-even reduction in the Distinguishability Geometry (DG)
Jacobi/Riccati response hierarchy.

## Claimed identity

With formal Lorentz-scalar extraction `Π`, in four-dimensional Ricci-flat
vacuum, after the vacuum EOM/Bianchi/derivative-commutator normal form and
modulo spacetime total divergences,

```text
F10 ≃ [106781 I2 I3 + 49431 P2 P3
       + 2187 I2 (∇C)^2 - 867 P2 (∇C·∇*C)] / 55738368000.
```

Here `F10` is the formal-`Π` projection of the exact five-term Jacobi-jet
representative at order `τ^10`. This is a geometric-response identity. It is
**not** a gravitational-action identity.

## Reviewer quick start

### Fast exact check — no third-party packages

```bash
python verify_tau10.py --fast
```

This runs three independent exact checks:

1. `DG_tau10_exact_audit.py` — raw 14→5 cyclic/IBP identity and original
   normalization lock;
2. `tau10_PROOF_A_spinor_count.py` — exact Lorentz/spinor-jet dimension count;
3. `solve_tau10_exact.py` — exact-`Q` 11×11 basis solve, determinant,
   divergence decomposition, and withheld Taub test.

The fast route uses the archived rational rows
`tau10_exact_taub_00.json` … `tau10_exact_taub_11.json`.

Expected terminal line:

```text
TAU^10 5->4 EXACT CERTIFICATE: PASS
```

### Full regeneration from the metric

```bash
python -m pip install -r requirements-full.txt
python verify_tau10.py --full
```

`--full` regenerates all 12 Taub/Bianchi-II rows from the metric and exact
tensor-jet engine before solving the certificate. It is substantially slower
than the fast check.

`numpy` is used only as an object-array container and `opt_einsum` as a tensor
contraction scheduler. The mathematical values are Python `Fraction` objects;
the determinant and linear solves are exact rational/integer arithmetic.

## What is actually proved by the finite evaluation matrix?

A finite background fit would not by itself prove a universal tensor identity.
The certificate relies on an independent exact dimension theorem first:

```text
dim S_even(10) = 11
              = 1[C^2 D^6] + 3[C^3 D^4] + 5[C^4 D^2] + 2[C^5].
```

The independent pure-gravity on-shell quotient count gives
`dim Q_even(10)=4`, hence `rank(div)=7`.

The four quotient candidates `Q1,...,Q4` and seven explicitly frozen
divergences `D1,...,D7` are then evaluated on 11 exact rational Ricci-flat
Taub/Bianchi-II probes. Their 11×11 evaluation matrix has nonzero determinant
over `Q`; therefore those 11 invariants form a basis of the already-proved
11-dimensional scalar space. The evaluation map is injective on that space.

The residual

```text
R = F10 - [106781 Q1 + 49431 Q2 + 2187 Q3 - 867 Q4]/55738368000
```

has exact full-basis coordinates

```text
(0, 0, 0, 0,
 -151/68812800,
  218669/13934592000,
 -1723/145152000,
 -1/7257600,
  1/116121600,
  1/23224320,
 -1/232243200).
```

Thus its four quotient coordinates vanish exactly and it is a linear
combination only of explicit divergences.

A twelfth Taub point, `b=3/10`, is withheld from the determinant and solve. Its
raw residual is nonzero, while `R - Σ α_i D_i` evaluates to exactly zero.

## Key exact checks

- `rank(B)=11` over `Q`;
- exact determinant is nonzero;
- `det(B) mod 1000003 = 895554`;
- all 11 basis probes have `Ricci=0` exactly;
- first four exact residual coordinates are `(0,0,0,0)`;
- all 11 basis residual checks are exactly zero;
- withheld Taub residual-minus-divergences is exactly zero;
- generic Taub convention lock checks `Π tr J^3`, `Π tr J^4`, `Π tr J^5` exactly.

## File map

- `verify_tau10.py` — reviewer entry point (`--fast` / `--full`).
- `DG_tau10_exact_audit.py` — exact raw 14→5 audit + original normalization lock.
- `tau10_PROOF_A_spinor_count.py` — exact representation-theory count.
- `tau10_PROOF_A_B0_spinor_basis.md` — scalar/current basis argument.
- `tau10_PROOF_A_certificate.txt` — compact Proof-A output.
- `tau10_proofB_exact.py` — exact tensor-jet engine and seven frozen currents.
- `run_tau10_taub_rows.py` — exact Taub row generator.
- `solve_tau10_exact.py` — exact determinant, solve, divergence decomposition,
  and withheld test.
- `tau10_PROOF_B_convention_lock.py` — generic Taub convention lock.
- `tau10_PROOF_B_exact_proof.md` — human-readable Proof-B derivation.
- `tau10_PROOF_B_exact_certificate.txt` — compact machine certificate.
- `tau10_exact_taub_00.json` … `tau10_exact_taub_10.json` — basis rows.
- `tau10_exact_taub_11.json` — withheld row.

## Scope / non-claims

The result is stated only within formal `Π`, `d=4` Ricci-flat vacuum, the
parity-even sector, vacuum EOM/Bianchi/commutator normal ordering, and
spacetime-IBP/boundary equivalence. It does not identify `Θ_G` with a
fundamental gravitational action and does not make the displayed coefficients
field-redefinition-invariant action couplings.

## Integrity

Run

```bash
sha256sum -c SHA256SUMS.txt
```

on Linux/macOS systems with `sha256sum`. The checksum file covers the
reviewer-facing source, data, proof, and certificate files in this package.
