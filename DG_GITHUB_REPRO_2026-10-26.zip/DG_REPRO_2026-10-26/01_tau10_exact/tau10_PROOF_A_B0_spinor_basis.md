# τ^10 PROOF A/B0 — exact 4D Ricci-flat spinor-jet basis

## 1. Vacuum Weyl jets

Work over the complexified Lorentz group SL(2,C) ≅ SU(2)_L × SU(2)_R.

Let

W_n^+ = Ψ^{(n)} ∈ (2+n/2, n/2),
W_n^- = \bar Ψ^{(n)} ∈ (n/2, 2+n/2),

where Ψ^{(n)} is the totally symmetrized n-th covariant derivative
of the self-dual Weyl spinor. In vacuum the differential Bianchi identity
removes the divergence descendants. Antisymmetrized derivative pairs are
reduced by [∇,∇] to lower jet level and higher Weyl degree, so the
symmetrized Weyl jets provide a triangular local normal form.

Notation:
- P_(jL,jR)[XY] is the Clebsch–Gordan projection of X⊗Y onto (jL,jR).
- <X,Y> is the invariant contraction of equal Lorentz irreps.
- "+ parity conjugate" means add the L↔R conjugate, producing a parity-even real scalar/current.

## 2. Exact dimension-10 parity-even scalar basis

The exact character count gives

dim S_even(10) = 11
               = 1[C^2 D^6] + 3[C^3 D^4] + 5[C^4 D^2] + 2[C^5].

A convenient basis is:

### C^2 D^6  (1)
S1 = <W_3^+, W_3^+> + parity conjugate.

### C^3 D^4  (3)
S2 = <W_0^+, P_(2,0)[W_2^+ W_2^+]> + parity conjugate.
S3 = <W_0^+, P_(2,0)[W_2^- W_2^-]> + parity conjugate.
S4 = <P_(3,1)[W_1^+ W_1^+], W_2^+> + parity conjugate.

Each displayed channel has Clebsch–Gordan multiplicity one.

### C^4 D^2  (5)
S5 = singlet(W_0^+ W_0^- W_1^+ W_1^-).

S6 = <P_(0,0)[W_0^+ W_0^+],
      P_(0,0)[W_1^- W_1^-]> + parity conjugate.

For J = 0,2,4:
S_(7+J/2) =
    <P_(J,0)[W_0^+ W_0^+],
     P_(J,0)[W_1^+ W_1^+]> + parity conjugate.

Thus explicitly:
S7 uses J=0,
S8 uses J=2,
S9 uses J=4.

The three channels exist because
Sym^2(2,0) = (4,0) ⊕ (2,0) ⊕ (0,0),
and Sym^2(5/2,1/2) contains each of those three irreps once.

### C^5  (2)
S10 = singlet((W_0^+)^5) + parity conjugate.
S11 = singlet((W_0^+)^3 (W_0^-)^2) + parity conjugate.

These two channels are the chiral form of the two parity-even algebraic
quintic Weyl structures. They may later be converted to the tensor basis
I2 I3 and P2 P3.

## 3. Independence and completeness

Completeness follows from the exact SU(2)_L × SU(2)_R character count.
Independence is immediate between different jet/chirality monomial types.
Within C^4 D^2, S7,S8,S9 belong to distinct intermediate irreps J=0,2,4,
so they are linearly independent by Schur orthogonality.

Therefore the local parity-even scalar space at mass dimension 10,
after vacuum EOM/Bianchi and derivative-commutator normal ordering but
before spacetime integration by parts, is exactly 11-dimensional.

## 4. Dimension-9 parity-even vector currents

The exact character count gives

dim V_even(9) = 8
              = 1[C^2 D^5] + 4[C^3 D^3] + 3[C^4 D].

A convenient channel basis is:

### C^2 D^5  (1)
V1 = vector(W_2^+ W_3^+) + parity conjugate.

### C^3 D^3  (4)
V2 = vector(W_0^+ W_1^- W_2^-) + parity conjugate.
V3 = vector((W_1^+)^3) + parity conjugate.

V4,V5 = the two independent vector projections of
         W_0^+ W_1^+ W_2^+ + parity conjugate.
A convenient coupling choice uses the intermediate W_1^+⊗W_2^+ channels
(3/2,1/2) and (5/2,1/2), respectively.

### C^4 D  (3)
V6 = vector(W_0^+ (W_0^-)^2 W_1^+) + parity conjugate.

V7,V8 = the two independent vector projections of
         (W_0^+)^3 W_1^+ + parity conjugate.
A convenient coupling choice projects Sym^3(W_0^+) first to spin
J_L=2 or J_L=3 (with J_R=0), respectively, and then couples to W_1^+
to obtain the Lorentz vector (1/2,1/2).

## 5. Exact divergence-rank consequence

The independent pure-gravity EFT Hilbert series at mass dimension 10 has
seven on-shell operators total:
C_L^5, C_L^3 C_R^2, C_L^2 C_R^3, C_R^5,
C_L^4 D^2, C_L^2 C_R^2 D^2, C_R^4 D^2.

Under parity these give 4 parity-even and 3 parity-odd classes.

Therefore, in the parity-even sector,

rank(div : V_even(9) -> S_even(10))
    = dim S_even(10) - dim Q_even(10)
    = 11 - 4
    = 7.

Since dim V_even(9)=8, ker(div) is one-dimensional.

This is an exact dimension statement. The remaining task (PROOF B proper)
is to calculate the explicit rational 7×11 divergence matrix and identify
a concrete seven-current image basis. No numerical metric fit is needed.
