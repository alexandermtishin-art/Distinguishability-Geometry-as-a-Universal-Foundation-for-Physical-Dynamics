#!/usr/bin/env python3
from tau10_proofB_exact import Q, build_taub, Jpoly_from_Dn, trace_word, pi_poly, invs_exact

b=Q(1,3); u=Q(2)
gj,igj,Gj,Rmix,Rcov,Dsj,exps=build_taub(b,u,6)
zero=(0,0); g=gj[zero]; gi=igj[zero]; Ds=[T[zero] for T in Dsj]
sqrtg=Q(1)+b*b
I2,I3,P2,P3,grad2,gradcross=invs_exact(Ds[0],Ds[1],g,gi,sqrtg)
J=Jpoly_from_Dn(Ds[0],gi)
pi3=pi_poly(trace_word([J,J,J]),6,gi)
pi4=pi_poly(trace_word([J,J,J,J]),8,gi)
pi5=pi_poly(trace_word([J,J,J,J,J]),10,gi)
print('Pi tr J^3 + I3/64 =',pi3 + I3/Q(64))
print('Pi tr J^4 - (6 I2^2+P2^2)/2560 =',pi4 - (Q(6)*I2*I2+P2*P2)/Q(2560))
print('Pi tr J^5 + (8 I2 I3+3 P2 P3)/6144 =',pi5 + (Q(8)*I2*I3+Q(3)*P2*P3)/Q(6144))
assert pi3 == -I3/Q(64)
assert pi4 == (Q(6)*I2*I2+P2*P2)/Q(2560)
assert pi5 == -(Q(8)*I2*I3+Q(3)*P2*P3)/Q(6144)
print('CONVENTION LOCK: PASS')
