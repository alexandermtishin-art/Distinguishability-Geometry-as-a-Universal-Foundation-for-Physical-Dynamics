# τ^10 PROOF B — exact 5→4 divergence certificate

**Status:** PASS / PROVED within the explicitly stated equivalence class below.

## 1. Statement and scope

Let `F10` denote the formal-Π projection of the exact five-term Jacobi-jet representative at order τ^10,

\[
F_{10}=\Pi\left[-\frac{31}{14175}\operatorname{tr}J^5
+\frac{307}{302400}\operatorname{tr}(J^2J'^2)
+\frac{101}{181440}\operatorname{tr}(JJ'JJ')
+\frac1{21600}\operatorname{tr}(JJ'''J')
+\frac1{1814400}\operatorname{tr}(J'''^2)\right].
\]

In four-dimensional Ricci-flat vacuum, in the parity-even sector, after vacuum EOM/Bianchi identities, derivative-commutator normal ordering and modulo spacetime total divergences,

\[
\boxed{
F_{10}\simeq
\frac{1}{55738368000}\left[
106781 I_2I_3+49431 P_2P_3+2187 I_2(\nabla C)^2
-867 P_2(\nabla C\!\cdot\!\nabla{}^*C)
\right].}
\]

This is an identity for the **geometric response coefficient** in the formal-Π prescription. It is not a pointwise identity before IBP and is not a derivation of a gravitational action.

Define

\[
Q_1=I_2I_3,\quad Q_2=P_2P_3,\quad
Q_3=I_2(\nabla C)^2,\quad
Q_4=P_2(\nabla C\cdot\nabla{}^*C).
\]

The target quotient coefficients are therefore

\[
\left(
\frac{106781}{55738368000},
\frac{16477}{18579456000},
\frac{9}{229376000},
-\frac{289}{18579456000}
\right).
\]

## 2. Exact dimension theorem used

The independent spinor-jet character calculation in `tau10_PROOF_A_spinor_count.py` and `tau10_PROOF_A_B0_spinor_basis.md` gives

\[
\dim S_{10}^{(+)}=11
=1[C^2D^6]+3[C^3D^4]+5[C^4D^2]+2[C^5].
\]

It also gives eight parity-even dimension-nine vector-current channels. Together with the independent pure-gravity dimension-ten on-shell quotient count,

\[
\dim Q_{10}^{(+)}=4,
\qquad
\operatorname{rank}(\mathrm{div})=11-4=7.
\]

Thus the remaining Proof-B task is not a dimension fit: it is to exhibit seven explicit divergences and show that `Q1,...,Q4,D1,...,D7` form a basis of the entire 11-dimensional local scalar space.

## 3. Explicit current convention

For a factor of derivative order `k`, the tensor is

\[
D^k C=\nabla_{a_1}\cdots\nabla_{a_k}C_{bcde},
\]

with array slots ordered as **derivative slots first, then the four Weyl slots**. A current pattern contains:

- `orders=(k_1,...,k_m)` for its factors;
- `free=(factor,slot)` for the one uncontracted covariant index;
- `pairs`, a list of slot pairs contracted with inverse metrics.

Its divergence is computed exactly by the covariant Leibniz rule: for each factor in turn, prepend one covariant-derivative slot and contract that new derivative index with the current's free index; then sum over all factors. Therefore every `D_i` below is, by construction, an explicit scalar of the form `∇_μ V_i^μ`.

The seven frozen current patterns are:

```text
D1 orders=(0,0,3), free=(1,0)
 pairs=(((2,5),(1,1)),((2,1),(1,2)),((2,4),(0,3)),((2,6),(0,1)),
        ((2,2),(2,0)),((0,2),(2,3)),((1,3),(0,0)))

D2 orders=(0,0,3), free=(0,1)
 pairs=(((1,0),(2,3)),((0,3),(2,5)),((2,6),(1,2)),((2,4),(1,3)),
        ((2,2),(0,0)),((0,2),(2,1)),((2,0),(1,1)))

D3 orders=(0,0,3), free=(1,2)
 pairs=(((2,6),(1,3)),((0,0),(2,3)),((2,4),(1,1)),((1,0),(0,3)),
        ((0,2),(2,2)),((2,5),(2,0)),((2,1),(0,1)))

D4 orders=(0,1,2), free=(2,3)
 pairs=(((0,1),(2,1)),((1,3),(0,3)),((1,0),(2,4)),((1,2),(2,0)),
        ((2,5),(0,0)),((1,1),(0,2)),((2,2),(1,4)))

D5 orders=(0,1,2), free=(2,5)
 pairs=(((2,0),(1,1)),((2,2),(0,2)),((2,3),(1,3)),((1,4),(2,4)),
        ((1,0),(0,1)),((0,0),(2,1)),((1,2),(0,3)))

D6 orders=(0,1,2), free=(1,1)
 pairs=(((1,3),(0,2)),((0,1),(2,0)),((0,3),(2,3)),((2,1),(1,2)),
        ((2,5),(1,0)),((2,4),(1,4)),((2,2),(0,0)))

D7 orders=(2,3), free=(1,0)
 pairs=(((1,4),(0,5)),((0,2),(1,5)),((1,3),(0,1)),
        ((0,3),(1,1)),((1,6),(0,4)),((0,0),(1,2)))
```

These are implemented literally in `tau10_proofB_exact.py`; no current is reselected during the rational solve.

## 4. Exact vacuum evaluation family

Use the Taub/Bianchi-II Ricci-flat family

\[
 ds^2=-A^2dt^2+t^{2p}A^{-2}(dx+4pbz\,dy)^2
      +t^{2q}A^2dy^2+t^{2s}A^2dz^2,
\]
\[
A^2=1+b^2t^{4p},
\qquad
(p,q,s)=(-2/7,3/7,6/7),
\]

corresponding to the fixed rational Kasner parameter `u=2`. Evaluate at `t=1,z=0`.

The eleven basis probes use

\[
b\in\left\{
\frac13,\frac14,\frac15,\frac25,\frac12,\frac27,\frac37,
\frac38,\frac49,\frac29,\frac5{11}
\right\}.
\]

For every probe, the Ricci tensor computed by the exact jet engine is **identically zero over Q**.

All metric jets, inverse-metric jets, Christoffels, curvature, covariant Weyl derivatives through the required order, formal-Π Wick contractions, invariants and divergences are evaluated with Python `Fraction`; no floating-point arithmetic is used in the certificate.

## 5. Convention lock on a magnetic/non-pure-electric vacuum point

At the first exact Taub probe (`b=1/3,u=2`), direct formal-Π contraction gives exactly

\[
\Pi\operatorname{tr}J^3=-\frac{I_3}{64},
\]
\[
\Pi\operatorname{tr}J^4=\frac{6I_2^2+P_2^2}{2560},
\]
\[
\Pi\operatorname{tr}J^5=-\frac{8I_2I_3+3P_2P_3}{6144}.
\]

All three residuals are exactly zero. This independently locks the Riemann sign, Hodge-dual convention and formal-Π normalization on a probe with nonzero pseudoscalars.

## 6. Exact 11×11 basis certificate

Form the evaluation matrix

\[
B=[Q_1,Q_2,Q_3,Q_4,D_1,\ldots,D_7]
\]

on the eleven rational Taub probes above. The exact computation gives

\[
\operatorname{rank}_{\mathbb Q}B=11,
\qquad \det_{\mathbb Q}B\neq0.
\]

As a compact independent check,

\[
\det B\equiv895554\pmod{1000003}\neq0.
\]

The complete exact rational determinant is stored verbatim in `tau10_PROOF_B_exact_certificate.txt` and is recomputed by `solve_tau10_exact.py` using denominator clearing plus the fraction-free Bareiss algorithm.

Because `dim S_10^(+)=11`, the eleven displayed scalars are therefore a basis of the entire local parity-even dimension-ten scalar space in the stated vacuum normal form. Equivalently, the eleven selected exact evaluation functionals are injective on that space.

## 7. Exact residual decomposition

Define

\[
R=F_{10}-\frac{106781Q_1+49431Q_2+2187Q_3-867Q_4}{55738368000}.
\]

Solving over `Q` gives

\[
R=\sum_{i=1}^{7}\alpha_iD_i,
\]

with

\[
\begin{aligned}
\alpha_1&=-\frac{151}{68812800},\\
\alpha_2&= \frac{218669}{13934592000},\\
\alpha_3&=-\frac{1723}{145152000},\\
\alpha_4&=-\frac1{7257600},\\
\alpha_5&= \frac1{116121600},\\
\alpha_6&= \frac1{23224320},\\
\alpha_7&=-\frac1{232243200}.
\end{aligned}
\]

The exact coordinates of `R` in the full basis `[Q1,Q2,Q3,Q4,D1,...,D7]` are

\[
\boxed{
\left(0,0,0,0,
-\frac{151}{68812800},
\frac{218669}{13934592000},
-\frac{1723}{145152000},
-\frac1{7257600},
\frac1{116121600},
\frac1{23224320},
-\frac1{232243200}\right).}
\]

Thus the four quotient coordinates of the residual vanish **exactly**, not numerically.

Equivalently, solving directly for `F10` gives full basis coordinates

\[
\boxed{
\left(
\frac{106781}{55738368000},
\frac{16477}{18579456000},
\frac{9}{229376000},
-\frac{289}{18579456000},
\alpha_1,\ldots,\alpha_7
\right).}
\]

The identity `R - Σ α_i D_i = 0` holds exactly on all eleven basis probes.

## 8. Why eleven finite evaluations are a proof here

Finite background matching by itself would not prove a universal tensor identity. The present argument is different:

1. representation theory proves **a priori** that the relevant local scalar space has dimension exactly 11;
2. `Q1,...,Q4,D1,...,D7` are eleven explicit elements of that same space;
3. their exact evaluation matrix has nonzero determinant, so they are linearly independent and hence form a basis;
4. the resulting evaluation map is therefore injective on the full 11-dimensional space;
5. `R-Σα_iD_i` belongs to that space and has eleven exactly vanishing coordinates under this injective map;
6. hence `R-Σα_iD_i` is the zero element of the local invariant space.

This is a finite-dimensional exact basis certificate, not a numerical fit.

## 9. Withheld exact veto

After all coefficients were frozen, a twelfth Taub point

\[
b=\frac3{10},\qquad u=2
\]

was evaluated independently. It was not used in the determinant or in solving for the coefficients. Its Ricci tensor again vanishes exactly, and

\[
R-\sum_i\alpha_iD_i=0
\]

**exactly over Q**.

The raw residual at this withheld point is nonzero,

\[
R=-\frac{8445493677963220493108568740000000}
{21607133935345658531501254976669676848121},
\]

so the test is genuinely checking the divergence decomposition rather than an accidental pointwise equality.

## 10. Conclusion

Within formal Lorentz-scalar extraction Π, four-dimensional Ricci-flat vacuum, the parity-even sector, vacuum EOM/Bianchi/commutator normal ordering, and spacetime integration-by-parts/boundary equivalence,

\[
\boxed{\tau^{10}\text{ 5→4 reduction: PROVED}.}
\]

Combined with the already exact raw 14-term coefficient, exact 14→5 Jacobi-jet IBP identity, odd-jet-to-spacetime-divergence lemma and normalization lock, the complete τ^10 response row is closed in this stated equivalence class.

No statement here promotes `Θ_G` to a gravitational action or makes the coefficient combination field-redefinition invariant as an EFT action coupling.

## 11. Reproduction files

- `DG_tau10_exact_audit.py` — exact raw 14→5 and original normalization lock.
- `tau10_PROOF_A_spinor_count.py` — exact representation-theory count.
- `tau10_PROOF_A_B0_spinor_basis.md` — explicit spinor-jet scalar/current basis argument.
- `tau10_PROOF_A_certificate.txt` — compact Proof-A output.
- `tau10_proofB_exact.py` — exact tensor-jet engine, four Q structures and seven frozen currents.
- `run_tau10_taub_rows.py` — generates the exact Taub rows.
- `solve_tau10_exact.py` — exact determinant, basis solve, residual decomposition and withheld check.
- `tau10_PROOF_B_convention_lock.py` — exact generic-Taub formal-Π convention lock.
- `tau10_PROOF_B_exact_certificate.txt` — compact machine-readable final certificate.
- `tau10_exact_taub_00.json` … `tau10_exact_taub_11.json` — exact rational evaluation records; row 11 is withheld.
