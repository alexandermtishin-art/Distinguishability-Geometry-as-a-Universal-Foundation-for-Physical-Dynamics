#!/usr/bin/env python3
"""Reviewer-facing verifier for the DG tau^10 5->4 certificate.

FAST (default): standard library only. Rechecks Proof A, the exact raw 14->5
identity/normalization lock, and solves the archived exact-Q 11x11 certificate
plus withheld row.

FULL: additionally regenerates all 12 exact Taub/Bianchi-II rows from the
metric/tensor-jet engine and reruns the generic Taub convention lock. Requires
numpy and opt_einsum.
"""
from __future__ import annotations
import argparse
import subprocess
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent


def run(script: str, *args: str) -> None:
    cmd = [sys.executable, str(BASE / script), *args]
    print("\n+", " ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=BASE, check=True)


def main() -> None:
    ap = argparse.ArgumentParser()
    mode = ap.add_mutually_exclusive_group()
    mode.add_argument("--fast", action="store_true", help="verify archived exact rows (default)")
    mode.add_argument("--full", action="store_true", help="regenerate all exact rows, then verify")
    args = ap.parse_args()

    run("DG_tau10_exact_audit.py")
    run("tau10_PROOF_A_spinor_count.py")

    if args.full:
        run("run_tau10_taub_rows.py", *[str(i) for i in range(12)])
        run("tau10_PROOF_B_convention_lock.py")

    run("solve_tau10_exact.py")
    print("\nTAU^10 5->4 EXACT CERTIFICATE: PASS", flush=True)
    if not args.full:
        print("FAST mode used archived exact-Q rows. Use --full to regenerate them from the metric.")


if __name__ == "__main__":
    main()
