# Appendix M: locality and boundary scaling
Run `python run_all.py`. Python standard library only.
The suite evaluates regular lattice dimensions 1–5, checks convergence of local exponents and held-out count errors below 1%, and displays binary-tree and single-edge bottleneck counterfamilies. The latter counts are exact consequences of the specified constructions; they do not simulate arbitrary graphs or derive a dynamics.
