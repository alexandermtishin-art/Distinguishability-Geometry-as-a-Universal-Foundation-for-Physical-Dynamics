# Reviewer checklist — Appendix M certificate

1. **Run it yourself.** `python3 run_all.py` (pure stdlib, no install needed).
   Compare against `FULL_OUTPUT.log`.

2. **Check the exact counts are really exact.** `boundary(L,s) =
   L**s - max(L-2,0)**s` is a closed-form integer identity (count of sites in
   an L×L×...×L block, s times, that touch at least one face), not a fit or
   simulation. Verify by hand for a small case, e.g. s=2, L=4:
   N=16, interior=(4-2)^2=4, boundary=12 — the 12 perimeter cells of a 4×4
   grid. Matches.

3. **Look for circularity.** The withheld test calibrates the local exponent
   at L*=2000 only, and predicts at L=20000, 200000, 2000000 — sizes never
   touched during calibration. The exact value at those held-out sizes is
   computed independently from the same closed-form `boundary_exact`, so this
   is a genuine out-of-sample check, not a restatement of the input formula.

4. **The logical point to attack.** This package does not, and does not
   claim to, derive why any particular architecture (if any) is physically
   selected. It only shows that *bounded-degree locality + finite propagation
   + a stable coarse response* is compatible with at least six different
   exponents across six explicit constructions (M.2's arbitrary-m(N) family,
   the five lattice dimensions s=1..5, the tree, and the bottleneck). If you
   believe locality alone *should* select β=2/3, the burden is to explain
   why five of these six architectures (all satisfying bounded-degree
   locality and finite propagation) are illegitimate — that argument is not
   supplied here and is flagged as the open item in Appendix M.5.

5. **Known limitation.** The lattice counterfamily's "boundary" is the
   standard outer-shell count for a hypercubic block; other reasonable
   notions of "interface" (e.g. graph Cheeger constant, mutual information
   across a cut) could in principle behave differently for the *same*
   architecture. This package tests the specific notion of interface stated
   in Appendix M.3 (bounded-degree lattice surface count), not every possible
   formalization of "interface complexity."
