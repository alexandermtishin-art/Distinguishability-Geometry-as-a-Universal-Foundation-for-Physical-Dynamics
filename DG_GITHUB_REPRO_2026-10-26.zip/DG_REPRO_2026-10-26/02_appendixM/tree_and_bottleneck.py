"""
Two further explicit architectures for Appendix M.3, exact integer counts.

(a) Regular binary tree of depth d: N = 2**(d+1) - 1 nodes, leaves = 2**d.
    "Interface" = leaf/boundary fraction. Claim: this is "order unity"
    (does not vanish as N grows) -- i.e. effectively beta -> 1, the
    OPPOSITE extreme from a compact lattice block.

(b) Bottleneck architecture: two blocks of N/2 vertices each, joined by a
    single edge (recursively, at every scale). The minimal cut separating
    the two halves is exactly 1 for every N. Claim: "much smaller
    effective exponents" -- here the smallest possible, beta = 0 exactly
    for all N (interface size is constant, not growing at all).
"""

def tree_leaf_fraction(d):
    N = 2**(d+1) - 1
    leaves = 2**d
    return N, leaves, leaves / N

def bottleneck_cut(N):
    # by construction, cut size is exactly 1 regardless of N (any N>=2)
    return N, 1

print("=== (a) Regular binary tree: leaf/boundary fraction vs depth ===")
print(f"{'depth d':>8} {'N (nodes)':>12} {'leaves':>10} {'leaf/N':>10}")
for d in [2, 4, 8, 12, 16, 20]:
    N, leaves, frac = tree_leaf_fraction(d)
    print(f"{d:8d} {N:12d} {leaves:10d} {frac:10.6f}")
print("-> ratio converges to exactly 1/2 (order unity), never vanishes: beta effectively = 1, not 2/3.")

print()
print("=== (b) Bottleneck architecture: cut size vs total size ===")
print(f"{'N':>12} {'min cut':>10}")
for N in [10, 100, 10_000, 1_000_000, 10**12]:
    N_, cut = bottleneck_cut(N)
    print(f"{N_:12d} {cut:10d}")
print("-> cut size is exactly 1 for every N: beta = 0 exactly, the architecture with the smallest")
print("   possible exponent, realized by construction, not by taking any limit.")
