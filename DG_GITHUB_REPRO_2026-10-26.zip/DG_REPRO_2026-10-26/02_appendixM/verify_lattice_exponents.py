"""Finite-size lattice boundary exponents and held-out extrapolation."""
import math
from fractions import Fraction as F

def log_boundary(L, s):
    # log(L^s - (L-2)^s), stable for large L
    if L <= 2:
        return math.log(L**s)  # boundary = N exactly when L<=2
    return s*math.log(L) + math.log1p(-(1 - 2.0/L)**s)

def log_N(L, s):
    return s*math.log(L)

def boundary_exact(L, s):
    return L**s - max(L-2, 0)**s

def N_exact(L, s):
    return L**s

def target_beta(s):
    return F(s - 1, s)

def beta_local(L, s):
    return (log_boundary(2*L, s) - log_boundary(L, s)) / (log_N(2*L, s) - log_N(L, s))

print("=== Local (two-point doubling) exponent -- convergence check ===")
print(f"{'s':>2} {'target':>10} " + " ".join(f"L={L:<9d}" for L in [10,100,1000,10000,100000]))
for s in range(1, 6):
    row = [f"{beta_local(L,s):10.6f}" for L in [10,100,1000,10000,100000]]
    print(f"{s:2d} {float(target_beta(s)):10.6f} " + " ".join(row))

for s in range(1, 6):
    errors = [abs(beta_local(L, s) - float(target_beta(s))) for L in [10,100,1000,10000,100000]]
    assert all(b <= a + 1e-9 for a,b in zip(errors,errors[1:])), (s, errors)

print()
print("=== Withheld extrapolation test ===")
print("Calibrate beta_local at L*=2000 (training); predict boundary at L_test >> L*, never used to fit.")
print(f"{'s':>2} {'L*':>6} {'beta_local(L*)':>15} {'L_test':>10} {'boundary_exact':>16} {'boundary_pred':>16} {'rel.err':>10}")
Lstar = 2000
L_tests = [20000, 200000, 2000000]
for s in range(1, 6):
    b_hat = beta_local(Lstar, s)
    N_star = N_exact(Lstar, s)
    b_star = boundary_exact(Lstar, s)
    for Lt in L_tests:
        Nt = N_exact(Lt, s)
        pred = b_star * (Nt / N_star)**b_hat
        exact = boundary_exact(Lt, s)
        relerr = abs(pred - exact)/exact
        assert relerr < .01, (s, Lt, relerr)
        print(f"{s:2d} {Lstar:6d} {b_hat:15.10f} {Lt:10d} {exact:16d} {pred:16.2f} {relerr:10.2e}")
