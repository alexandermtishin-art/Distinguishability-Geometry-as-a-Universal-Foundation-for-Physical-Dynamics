# Covariance clock reconstruction checks

Reproducibility package for the standalone clock-reconstruction article, revision 4, 17 November 2026. This package contains six scientific scripts, their results and Figure 1. Manuscript files and internal editorial reports are excluded.

Use Python 3.10 or later with NumPy, SciPy, SymPy, mpmath and Matplotlib installed. Run from the extracted package root:

    python core/verify_clock_core.py
    python core/verify_plane_wave.py
    python core/verify_clock_stability.py
    python core/verify_discrete_snapshots.py
    python core/verify_discrete_bounds.py
    python core/verify_matrix_rejection.py

The first five scripts write JSON beside themselves in `core/`. The sixth writes `matrix_rejection_results.json`, `figure1_clock_matrix.pdf` and `figure1_clock_matrix.png` to the package root. It checks compatible and incompatible records with deterministic bounded errors, and evaluates the analytic rejection margin using outward-rounded scalar interval arithmetic.

The first script checks the exact bracket identity, a constant-norm counterexample and a numerical three-cloud reconstruction. The second checks curvature, a parallel frame and Jacobi factors for the exact vacuum plane wave. The third propagates smooth covariance errors through the clock estimator. The fourth constructs continuous estimates from discrete noisy snapshots. The fifth verifies the displayed upper bounds by interval arithmetic. The sixth checks the full matrix rejection residual, including an analytic margin that does not require a validated numerical ODE solve.

All records are analytic constructions or deterministic simulations. No experimental observations or probability model are supplied. The continuum bounds require the stated spectral floor, preparation assumptions, regularity constants and covariance/derivative error budgets. Floating-point maxima and tightened solver tolerances are reproducibility diagnostics. They do not certify the numerical transport or quadrature errors. Passing a necessary residual threshold is not a proof of compatibility.

The article uses ζ for the transport-error bound and z for the plane-wave dimensionless proper time. The Python implementations may use the local variable name `z` for a transport bound. This naming does not alter their formulas.

`SHA256SUMS.txt` records every included file except itself. Dependencies are listed in `requirements.txt`. Figures can be regenerated with the sixth script.
