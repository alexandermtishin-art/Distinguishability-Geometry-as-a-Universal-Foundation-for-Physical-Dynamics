"""Exact counterexample and numerical covariance reconstruction for Jacobi clocks."""
import json
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import solve_sylvester
import sympy as sp


def exact_counterexample():
    label = sp.symbols("label", real=True)
    first = sp.eye(2)
    second = sp.diag(2 + sp.sin(label), 2 + sp.cos(label))
    third = second + first
    factors = [first, second, third]
    brackets = []
    norms = []
    for i, j in ((0, 1), (0, 2), (1, 2)):
        bracket = factors[i].T * factors[j].diff(label) - factors[i].diff(label).T * factors[j]
        square = sp.simplify(sp.trace(bracket.T * bracket))
        assert square == 1
        brackets.append(bracket)
        norms.append(str(square))
    assert any(x != 0 for x in brackets[0].diff(label))
    # A constant first solution forces the common force matrix to vanish.
    assert any(x != 0 for x in second.diff(label, 2))
    return dict(pair_squared_norms=norms, compatible_with_shared_dynamics=False)


def tidal_matrix(time):
    angle = 0.6 * time
    rotation = np.array([[np.cos(angle), -np.sin(angle), 0],
                         [np.sin(angle), np.cos(angle), 0], [0, 0, 1]])
    return rotation @ np.diag([0.10, -0.05, 0.08]) @ rotation.T


def evolution(time, state):
    position = state[:9].reshape(3, 3)
    velocity = state[9:].reshape(3, 3)
    return np.concatenate((velocity.ravel(), (tidal_matrix(time) @ position).ravel()))


def covariance_reconstruction():
    labels = np.linspace(0, 0.7, 101)
    lapse = np.exp(0.4 * labels)
    times = np.expm1(0.4 * labels) / 0.4
    initial_velocities = [
        np.diag([0.1, -0.05, 0.2]),
        np.diag([0.4, 0.2, -0.1]),
        np.array([[0.2, 0.07, 0], [0.07, -0.1, 0.03], [0, 0.03, 0.15]]),
    ]
    positions = []
    velocities = []
    covariances = []
    recovered_rates = []
    for initial_velocity in initial_velocities:
        state = np.concatenate((np.eye(3).ravel(), initial_velocity.ravel()))
        solution = solve_ivp(evolution, (0, times[-1]), state, t_eval=times,
                             method="DOP853", rtol=2e-12, atol=2e-13)
        assert solution.success
        x = solution.y[:9].T.reshape(-1, 3, 3)
        u = solution.y[9:].T.reshape(-1, 3, 3)
        s = x @ x.transpose(0, 2, 1)
        derivatives = lapse[:, None, None] * (
            u @ x.transpose(0, 2, 1) + x @ u.transpose(0, 2, 1))
        b = np.array([solve_sylvester(si, si, di) for si, di in zip(s, derivatives)])
        positions.append(x)
        velocities.append(u)
        covariances.append(s)
        recovered_rates.append(b)

    max_clock_error = 0.0
    max_bracket_error = 0.0
    minimum_eigenvalue = np.inf
    for s in covariances:
        minimum_eigenvalue = min(minimum_eigenvalue, np.linalg.eigvalsh(s).min())
    for i, j in ((0, 1), (1, 2), (0, 2)):
        d = recovered_rates[j] - recovered_rates[i]
        m = np.trace(covariances[i] @ d @ covariances[j] @ d, axis1=1, axis2=2)
        assert np.all(m > 0)
        recovered_lapse = np.sqrt(m / m[0])
        max_clock_error = max(max_clock_error, abs(recovered_lapse - lapse / lapse[0]).max())
        w = positions[i].transpose(0, 2, 1) @ d @ positions[j]
        normalized = w / recovered_lapse[:, None, None]
        max_bracket_error = max(max_bracket_error, abs(normalized - normalized[0]).max())
    assert max_clock_error < 1e-9
    assert max_bracket_error < 1e-9
    return dict(sample_labels=len(labels), clouds=3,
                minimum_covariance_eigenvalue=float(minimum_eigenvalue),
                maximum_lapse_error=float(max_clock_error),
                maximum_normalized_bracket_error=float(max_bracket_error),
                numerical_tolerance=1e-9)


def exact_reparametrization_identity():
    label = sp.symbols("label", real=True)
    v = sp.exp(label / 3)
    time = 3 * sp.exp(label / 3)
    x = sp.diag(1 + time, 1 + 2 * time)
    y = sp.diag(2 + 3 * time, 4 - time)
    w = x.T * y.diff(label) - x.diff(label).T * y
    normalized_derivative = (w / v).diff(label).applyfunc(sp.simplify)
    assert normalized_derivative == sp.zeros(2)
    return dict(normalized_wronskian_constant=True)


if __name__ == "__main__":
    report = dict(exact_reparametrization=exact_reparametrization_identity(),
                  exact_counterexample=exact_counterexample(),
                  numerical_covariance_test=covariance_reconstruction())
    text = json.dumps(report, indent=2)
    Path(__file__).with_name("clock_core_results.json").write_text(text + "\n")
    print(text)
