"""Smooth deterministic covariance perturbations and the transported clock bound."""
import json
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import solve_sylvester


LENGTH = np.log(1.5)
COEFFICIENTS = [(0, 0, 0), (0.4, -0.2, 0.3)]
DIRECTIONS = [
    np.array([[1, 0.2, 0], [0.2, -0.4, 0.1], [0, 0.1, 0.3]]),
    np.array([[-0.3, 0.1, 0.2], [0.1, 0.8, 0], [0.2, 0, -0.4]]),
]
DIRECTIONS = [matrix / np.linalg.norm(matrix) for matrix in DIRECTIONS]


def covariance(label, cloud):
    z = np.expm1(label)
    lapse = np.exp(label)
    a, b, c = COEFFICIENTS[cloud]
    factor = np.array([np.cosh(z) + a*np.sinh(z),
                       np.cos(z) + b*np.sin(z), 1 + c*z])
    velocity = np.array([np.sinh(z) + a*np.cosh(z),
                         -np.sin(z) + b*np.cos(z), c])
    return np.diag(factor**2), np.diag(2*lapse*factor*velocity)


def estimated_rate(label, cloud, error):
    s, derivative = covariance(label, cloud)
    phase = (0.3, 0.8)[cloud]
    estimate = s + error*np.sin(label+phase)*DIRECTIONS[cloud]
    estimated_derivative = derivative + error*np.cos(label+phase)*DIRECTIONS[cloud]
    return solve_sylvester(estimate, estimate, estimated_derivative)


def evaluate(error):
    def equation(label, state):
        transports = state.reshape(2, 3, 3)
        return np.array([estimated_rate(label, i, error) @ transports[i]
                         for i in range(2)]).ravel()

    labels = np.linspace(0, LENGTH, 101)
    initial = np.array([np.eye(3), np.eye(3)]).ravel()
    solution = solve_ivp(equation, (0, LENGTH), initial, t_eval=labels,
                         method="DOP853", rtol=2e-12, atol=2e-13)
    assert solution.success
    qhat0 = estimated_rate(0, 1, error) - estimated_rate(0, 0, error)
    q0 = np.diag([0.4, -0.2, 0.3])
    gamma = np.linalg.norm(q0)
    rho = np.exp(labels)
    estimates = []
    for label, state in zip(labels, solution.y.T):
        phi1, phi2 = state.reshape(2, 3, 3)
        q = estimated_rate(label, 1, error) - estimated_rate(label, 0, error)
        transported = phi1.T @ q @ phi2
        estimates.append(np.vdot(transported, qhat0) / np.vdot(qhat0, qhat0))

    # Analytic uniform bounds for all three declared plane-wave preparations.
    m = 0.6
    u = 6.0
    b = 1.8  # Direct analytic bound on B for the declared plane-wave preparations.
    d = (error + 2*b*error) / (2*(m-error))
    beta = np.exp(b*LENGTH)
    betahat = np.exp((b+d)*LENGTH)
    z = d*LENGTH*betahat
    delta = 2*(b+d)*z*betahat + 2*d*beta*betahat + 2*b*beta*z
    assert gamma > 2*d
    bound = (delta + 2*d*rho)/(gamma-2*d)
    observable_bound = (delta + 4*b*beta**2*d/gamma)/(gamma-2*d)
    actual = abs(np.array(estimates)-rho)
    assert np.all(actual <= bound + 1e-9)
    assert bound.max() <= observable_bound
    return dict(covariance_error_bound=error, derivative_error_bound=error,
                maximum_observed_clock_error=float(actual.max()),
                maximum_clock_error_bound=float(bound.max()),
                clock_error_bound_without_true_lapse=float(observable_bound),
                smallest_reference_denominator=float(gamma-2*d))


if __name__ == "__main__":
    result = dict(window_length=float(LENGTH), spectral_lower_bound=0.6,
                  covariance_derivative_bound=6.0, deformation_rate_bound=1.8,
                  cases=[evaluate(error) for error in (1e-6, 1e-5, 1e-4, 1e-3)])
    text = json.dumps(result, indent=2)
    Path(__file__).with_name("clock_stability_results.json").write_text(text + "\n")
    print(text)
