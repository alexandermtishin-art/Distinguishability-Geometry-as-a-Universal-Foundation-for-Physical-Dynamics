"""Interval evaluation of the finite-snapshot upper bounds in Table 1."""
import json
from pathlib import Path

from mpmath import iv
import sympy as sp

iv.dps = 45


def bound(samples):
    epsilon = iv.mpf("0.000001")
    length = iv.ln(iv.mpf(3)/2)
    h = length/(samples-1)
    r = iv.exp(h)
    z0 = r-1
    cosh = (iv.exp(z0)+iv.exp(-z0))/2
    sinh = (iv.exp(z0)-iv.exp(-z0))/2
    cosine, sine = iv.cos(z0), iv.sin(z0)
    q = [r*(iv.mpf(2)/5)/(cosh*(cosh+(iv.mpf(2)/5)*sinh)),
         r*(-iv.mpf(1)/5)/(cosine*(cosine-(iv.mpf(1)/5)*sine)),
         r*(iv.mpf(3)/10)/(1+(iv.mpf(3)/10)*z0)]
    gamma = iv.sqrt(sum(value**2 for value in q))
    e0 = epsilon + 25*h**2/8
    e1 = epsilon/h + (iv.mpf(7)/24)*125*h**2
    m, b = iv.mpf(3)/5, iv.mpf(9)/5
    d = (e1+2*b*e0)/(2*(m-e0))
    window = length-2*h
    beta = iv.exp(b*window)
    betahat = iv.exp((b+d)*window)
    transport_error = d*window*betahat
    delta = (2*(b+d)*transport_error*betahat
             + 2*d*beta*betahat + 2*b*beta*transport_error)
    assert (gamma-2*d).a > 0
    upper = (delta+4*b*beta**2*d/gamma)/(gamma-2*d)
    displayed = {41: "0.565", 81: "0.167", 161: "0.0841", 321: "0.105"}[samples]
    assert upper.b < iv.mpf(displayed)
    return dict(snapshots=samples, exact_bound_interval=str(upper),
                displayed_upper_bound=displayed,
                displayed_bound_exceeds_interval=True)


if __name__ == "__main__":
    r = sp.Rational
    g1 = 2*r(7, 5)*r(33, 25)
    g2 = 2*(r(33, 25)**2+r(7, 5)*r(91, 50))
    g3 = 2*(3*r(33, 25)*r(91, 50)+r(7, 5)*r(33, 25))
    assert r(3, 2)*g1+r(9, 4)*g2 < 25
    assert r(3, 2)*g1+3*r(9, 4)*g2+r(27, 8)*g3 < 125
    result = dict(interval_decimal_precision=45,
                  analytic_regularities_verified=True,
                  cases=[bound(samples) for samples in (41, 81, 161, 321)])
    text = json.dumps(result, indent=2)
    Path(__file__).with_name("discrete_bound_intervals.json").write_text(text+"\n")
    print(text)
