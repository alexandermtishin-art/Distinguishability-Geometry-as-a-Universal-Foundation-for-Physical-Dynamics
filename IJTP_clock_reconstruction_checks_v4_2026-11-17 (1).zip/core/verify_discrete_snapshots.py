"""Finite covariance snapshots, interpolated derivatives and clock-error bounds."""
import json
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import solve_sylvester

from verify_clock_stability import covariance, DIRECTIONS, LENGTH


K2 = 25.0
K3 = 125.0
NOISE = 1e-6


def interpolate(values, grid, label):
    return np.array([[np.interp(label, grid, values[:, i, j])
                      for j in range(3)] for i in range(3)])


def check(samples):
    grid = np.linspace(0, LENGTH, samples)
    step = grid[1] - grid[0]
    measured = []
    derivatives = []
    for cloud in range(2):
        exact = np.array([covariance(label, cloud)[0] for label in grid])
        pattern = np.take([1, 1, -1, -1], (np.arange(samples) + cloud) % 4)
        noisy = exact + NOISE*pattern[:, None, None]*DIRECTIONS[cloud]
        measured.append(noisy)
        derivatives.append((noisy[2:] - noisy[:-2]) / (2*step))
    derivative_grid = grid[1:-1]
    start, end = derivative_grid[0], derivative_grid[-1]
    e0 = NOISE + K2*step**2/8
    e1 = NOISE/step + 7*K3*step**2/24
    m = 0.6
    b = 1.8
    d = (e1 + 2*b*e0)/(2*(m-e0))
    assert m > e0

    def estimated_rate(label, cloud):
        s = interpolate(measured[cloud], grid, label)
        u = interpolate(derivatives[cloud], derivative_grid, label)
        return solve_sylvester(s, s, u)

    def true_rate(label, cloud):
        s, u = covariance(label, cloud)
        return solve_sylvester(s, s, u)

    q0 = true_rate(start, 1) - true_rate(start, 0)
    qhat0 = estimated_rate(start, 1) - estimated_rate(start, 0)
    gamma = np.linalg.norm(q0)
    assert gamma > 2*d
    window = end - start
    beta = np.exp(b*window)
    betahat = np.exp((b+d)*window)
    z = d*window*betahat
    delta = 2*(b+d)*z*betahat + 2*d*beta*betahat + 2*b*beta*z
    uniform_bound = (delta + 4*b*beta**2*d/gamma)/(gamma-2*d)

    def equation(label, state):
        transports = state.reshape(2, 3, 3)
        return np.array([estimated_rate(label, cloud) @ transports[cloud]
                         for cloud in range(2)]).ravel()

    def ratio(label, state):
        phi1, phi2 = state.reshape(2, 3, 3)
        q = estimated_rate(label, 1) - estimated_rate(label, 0)
        h = phi1.T @ q @ phi2
        return np.vdot(h, qhat0) / np.vdot(qhat0, qhat0)

    # End every integration segment at an interpolation knot.
    state = np.array([np.eye(3), np.eye(3)]).ravel()
    labels = [start]
    estimates = [ratio(start, state)]
    for left, right in zip(derivative_grid[:-1], derivative_grid[1:]):
        evaluation = [(left+right)/2, right]
        solution = solve_ivp(equation, (left, right), state, t_eval=evaluation,
                             method="DOP853", rtol=2e-11, atol=2e-13)
        assert solution.success
        for label, output_state in zip(evaluation, solution.y.T):
            labels.append(label)
            estimates.append(ratio(label, output_state))
        state = solution.y[:, -1]

    errors = abs(np.array(estimates) - np.exp(np.array(labels)-start))
    assert errors.max() <= uniform_bound
    covariance_errors = []
    derivative_errors = []
    for label in labels:
        for cloud in range(2):
            exact_s, exact_u = covariance(label, cloud)
            covariance_errors.append(np.linalg.norm(
                interpolate(measured[cloud], grid, label) - exact_s))
            derivative_errors.append(np.linalg.norm(
                interpolate(derivatives[cloud], derivative_grid, label) - exact_u))
    assert max(covariance_errors) <= e0
    assert max(derivative_errors) <= e1
    return dict(snapshots_per_cloud=samples, spacing=float(step),
                retained_label_interval=[float(start), float(end)],
                uniform_covariance_error_bound=float(e0),
                uniform_derivative_error_bound=float(e1),
                sampled_max_covariance_error=float(max(covariance_errors)),
                sampled_max_derivative_error=float(max(derivative_errors)),
                sampled_max_clock_error=float(errors.max()),
                continuum_clock_error_bound=float(uniform_bound),
                reference_bracket_gap=float(gamma-2*d))


if __name__ == "__main__":
    results = dict(noise_bound=NOISE, second_derivative_bound=K2,
                   third_derivative_bound=K3,
                   cases=[check(samples) for samples in (41, 81, 161, 321)])
    text = json.dumps(results, indent=2)
    Path(__file__).with_name("discrete_snapshot_results.json").write_text(text + "\n")
    print(text)
