"""Deterministic noisy full-matrix necessary test; synthetic data, no statistics.

Run with Python 3, numpy, scipy, matplotlib, mpmath. JSON and Figure 1 are regenerated.
Floating-point ODE solutions are illustrative; the counterexample also has an
analytic rejection margin independent of numerical transport validation.
"""
import json
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import solve_sylvester


ROOT = Path(__file__).resolve().parent.parent
CASES = {
    "plane_wave": dict(length=float(np.log(1.5)), dimension=3, m=0.6, u=6., b=1.8),
    "rotating_bracket": dict(length=0.5, dimension=2, m=1., u=6., b=1.),
}


def record(label, cloud, name):
    if name == "plane_wave":
        z, r = np.expm1(label), np.exp(label)
        a, b, c = [(0., 0., 0.), (0.4, -0.2, 0.3)][cloud]
        f = np.array([np.cosh(z)+a*np.sinh(z), np.cos(z)+b*np.sin(z), 1+c*z])
        fp = r*np.array([np.sinh(z)+a*np.cosh(z), -np.sin(z)+b*np.cos(z), c])
    elif cloud == 0:
        f, fp = np.ones(2), np.zeros(2)
    else:
        f = np.array([2+np.sin(label), 2+np.cos(label)])
        fp = np.array([np.cos(label), -np.sin(label)])
    return np.diag(f*f), np.diag(2*f*fp)


def direction(n, cloud):
    matrices = [np.array([[1., .2, 0.], [.2, -.4, .1], [0., .1, .3]]),
                np.array([[-.3, .1, .2], [.1, .8, 0.], [.2, 0., -.4]])]
    matrix = matrices[cloud][:n, :n]
    return matrix/np.linalg.norm(matrix, "fro")


def rate(label, cloud, error, name):
    s, sp = record(label, cloud, name)
    # Exact differentiation: both Frobenius budgets are at most error.
    phase = [.3, .8][cloud]
    e = direction(len(s), cloud)
    shat = s+error*np.sin(label+phase)*e
    uhat = sp+error*np.cos(label+phase)*e
    return solve_sylvester(shat, shat, uhat)


def budgets(error, constants, qhatnorm):
    m, b, length = (constants[key] for key in ("m", "b", "length"))
    assert error < m
    d = (error+2*b*error)/(2*(m-error))
    beta = np.exp(b*length)
    betahat = np.exp((b+d)*length)
    z = d*length*betahat
    delta = 2*(b+d)*z*betahat+2*d*beta*betahat+2*b*beta*z
    gamma_lower = qhatnorm-2*d
    assert gamma_lower > 0
    threshold = delta+4*b*beta**2*d/gamma_lower
    return dict(e0=error, e1=error, d=float(d), beta=float(beta),
                betahat=float(betahat), z=float(z), delta=float(delta),
                observed_reference_norm=float(qhatnorm), gamma_lower=float(gamma_lower),
                necessary_residual_cap=float(threshold))


def evaluate(name, error, rtol=2e-12, atol=2e-13):
    constants = CASES[name]
    n, length = constants["dimension"], constants["length"]
    labels = np.linspace(0, length, 201)
    def equation(label, state):
        phi = state.reshape(2, n, n)
        return np.array([rate(label, k, error, name)@phi[k] for k in range(2)]).ravel()
    sol = solve_ivp(equation, (0, length), np.tile(np.eye(n), (2, 1, 1)).ravel(),
                    t_eval=labels, method="DOP853", rtol=rtol, atol=atol)
    assert sol.success
    qhat0 = rate(0, 1, error, name)-rate(0, 0, error, name)
    qnorm = np.linalg.norm(qhat0, "fro")
    enclosure = budgets(error, constants, qnorm)
    residuals, ratios, matrix_errors = [], [], []
    for label, state in zip(labels, sol.y.T):
        phi1, phi2 = state.reshape(2, n, n)
        hhat = phi1.T@(rate(label, 1, error, name)-rate(label, 0, error, name))@phi2
        ratio = np.vdot(hhat, qhat0)/qnorm**2
        residuals.append(np.linalg.norm(hhat-ratio*qhat0, "fro"))
        ratios.append(ratio)
        if name == "plane_wave":
            exact_h = np.exp(label)*np.diag([.4, -.2, .3])
        else:
            exact_h = np.diag([np.cos(label)/2, -np.sin(label)/3])
        matrix_errors.append(np.linalg.norm(hhat-exact_h, "fro"))
    residuals, ratios = np.array(residuals), np.array(ratios)
    # Tiny additive tolerances below check floating-point computations only.
    assert max(matrix_errors) <= enclosure["delta"]+2e-10
    result = dict(case=name, constants=constants, **enclosure,
                  maximum_sampled_residual=float(max(residuals)),
                  endpoint_residual=float(residuals[-1]),
                  maximum_sampled_transport_matrix_error=float(max(matrix_errors)),
                  endpoint_numerical_exclusion_margin=float(residuals[-1]-enclosure["necessary_residual_cap"]),
                  ode_rtol=rtol, ode_atol=atol)
    if name == "plane_wave":
        assert max(residuals) <= enclosure["necessary_residual_cap"]+2e-10
        result["maximum_sampled_lapse_error"] = float(max(abs(ratios-np.exp(labels))))
        result["exact_noise_free_residual"] = 0.
        result["exclusion_triggered"] = False
    else:
        exact_endpoint = np.sin(length)/3
        # dist(Hhat, span(qhat0)) >= dist(H, span(q0)) - delta
        #                                  - ||H|| ||P_qhat-P_q||_2.
        # sin(angle(qhat0,q0)) <= 2d/||qhat0|| <= 2d/gamma_lower.
        # ||H|| <= 1/2 for this counterexample, throughout the chosen interval.
        analytic_lower = exact_endpoint-enclosure["delta"]-enclosure["d"]/enclosure["gamma_lower"]
        analytic_margin = analytic_lower-enclosure["necessary_residual_cap"]
        uniform_gamma_lower = .5-4*enclosure["d"]
        assert uniform_gamma_lower > 0
        uniform_cap = enclosure["delta"]+4*constants["b"]*enclosure["beta"]**2*enclosure["d"]/uniform_gamma_lower
        uniform_lower = exact_endpoint-enclosure["delta"]-enclosure["d"]/uniform_gamma_lower
        result.update(exact_endpoint_residual=float(exact_endpoint),
                      analytic_endpoint_residual_lower_bound=float(analytic_lower),
                      analytic_exclusion_margin=float(analytic_margin),
                      perturbation_uniform_gamma_lower=float(uniform_gamma_lower),
                      perturbation_uniform_necessary_cap=float(uniform_cap),
                      perturbation_uniform_endpoint_residual_lower_bound=float(uniform_lower),
                      perturbation_uniform_exclusion_margin=float(uniform_lower-uniform_cap),
                      exclusion_triggered=bool(analytic_margin > 0))
        assert analytic_margin > 0
        assert uniform_lower > uniform_cap
        if error == 0:
            result["maximum_error_against_exact_residual"] = float(max(abs(residuals-np.sin(labels)/3)))
            assert result["maximum_error_against_exact_residual"] < 2e-10
    return result, dict(labels=labels, residuals=residuals, ratios=ratios)


def figure(control, rejected, cap):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 10, "axes.labelsize": 10,
                         "axes.titlesize": 10, "legend.fontsize": 10,
                         "xtick.labelsize": 10, "ytick.labelsize": 10,
                         "pdf.fonttype": 42, "ps.fonttype": 42})
    fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.65), layout="constrained")
    x = control["labels"]
    axes[0].plot(x, np.exp(x), color="#264e70", label=r"True $e^\lambda$", linewidth=1.8)
    indices = np.arange(0, len(x), 20)
    axes[0].plot(x[indices], control["ratios"][indices], "o", markersize=4,
                 markerfacecolor="none", color="#bb4a21", label="Recovered")
    axes[0].set(xlabel=r"Plane-wave label $\lambda$", ylabel="Relative lapse",
                title="(a) Compatible synthetic records", xlim=(0, np.log(1.5)))
    axes[0].set_xticks([0, .2, np.log(1.5)], ["0", "0.2", r"$\log(3/2)$"])
    axes[0].legend(frameon=False, loc="upper left")
    axes[1].plot(rejected["labels"], rejected["residuals"], color="#264e70", label=r"Matrix residual $\widehat R$", linewidth=1.8)
    axes[1].axhline(cap, color="#bb4a21", linestyle="--", linewidth=1.5, label="Error threshold")
    axes[1].set(xlabel=r"Counterexample label $\lambda$", ylabel="Frobenius residual",
                title=r"(b) Counterexample ($\epsilon=10^{-5}$)", xlim=(0, .5))
    axes[1].legend(frameon=False, loc="upper left")
    for ax in axes:
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(alpha=.18)
    for suffix in ("pdf", "png"):
        fig.savefig(ROOT/f"figure1_clock_matrix.{suffix}", dpi=300)
    plt.close(fig)


def interval_certificate():
    """Outward-rounded scalar verification, not an ODE enclosure."""
    from mpmath import iv
    iv.dps = 45
    epsilon, m, b, length = iv.mpf("0.00001"), iv.mpf(1), iv.mpf(1), iv.mpf(1)/2
    d = (epsilon+2*b*epsilon)/(2*(m-epsilon))
    beta, betahat = iv.exp(b*length), iv.exp((b+d)*length)
    z = d*length*betahat
    delta = 2*(b+d)*z*betahat+2*d*beta*betahat+2*b*beta*z
    gstar = iv.mpf(1)/2-4*d
    cap = delta+4*b*beta**2*d/gstar
    exact_residual = iv.sin(length)/3
    lower_residual = exact_residual-delta-d/gstar
    margin = lower_residual-cap
    assert d.b < iv.mpf("0.000015001")
    assert delta.b < iv.mpf("0.000164")
    assert gstar.a > iv.mpf("0.49993999")
    assert cap.b < iv.mpf("0.000490")
    assert exact_residual.a > iv.mpf("0.1598085")
    assert lower_residual.a > iv.mpf("0.15961")
    assert margin.a > iv.mpf("0.15912")
    return dict(interval_decimal_precision=45, scope="Scalar analytic bounds only; no numerical ODE validation.",
                d_interval=str(d), delta_interval=str(delta), gstar_interval=str(gstar),
                cap_interval=str(cap), exact_endpoint_residual_interval=str(exact_residual),
                endpoint_residual_lower_bound_interval=str(lower_residual),
                exclusion_margin_interval=str(margin),
                verified_displayed_inequalities=["d < 0.000015001", "delta < 0.000164", "gstar > 0.49993999",
                    "cap < 0.000490", "sin(1/2)/3 > 0.1598085", "Rhat(1/2) > 0.15961", "Rhat(1/2)-cap > 0.15912"])


def main():
    rows, series = [], {}
    for name in CASES:
        for error in (0., 1e-6, 1e-5, 1e-4, 1e-3):
            row, curve = evaluate(name, error)
            rows.append(row)
            if error == 1e-5:
                series[name] = curve
    # A tighter solve is a reproducibility diagnostic, not a validated enclosure.
    stability = {}
    for name in CASES:
        _, tighter = evaluate(name, 1e-5, rtol=3e-14, atol=3e-15)
        stability[name] = float(max(abs(tighter["residuals"]-series[name]["residuals"])))
    cap = next(r["necessary_residual_cap"] for r in rows if r["case"] == "rotating_bracket" and r["e0"] == 1e-5)
    figure(series["plane_wave"], series["rotating_bracket"], cap)
    output = dict(interpretation="Necessary exclusion only; passing the cap is not a compatibility proof.",
                  numerics="Floating-point transport is not interval validated. Analytic counterexample margin does not rely on it.",
                  perturbation="S_hat=S+epsilon sin(lambda+phase_k) E_k, U_hat=S_prime+epsilon cos(lambda+phase_k) E_k; phases=(0.3,0.8), ||E_k||_F=1.",
                  cases=rows, tighter_solve_maximum_residual_difference=stability,
                  analytic_interval_certificate=interval_certificate())
    text = json.dumps(output, indent=2)
    (ROOT/"matrix_rejection_results.json").write_text(text+"\n")
    print(text)


if __name__ == "__main__":
    main()
