"""Exact vacuum metric, Jacobi factors and covariance clock on one timelike geodesic."""
import json
from pathlib import Path

import sympy as sp

u, w, x, y = sp.symbols("u w x y", real=True)
omega = sp.symbols("omega", positive=True)
coordinates = (u, w, x, y)
g = sp.Matrix([[2 * omega**2 * (x*x-y*y), -1, 0, 0],
               [-1, 0, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
inverse = g.inv()


def connection(a, b, c):
    return sp.simplify(sum(inverse[a, d] * (
        sp.diff(g[d, c], coordinates[b]) + sp.diff(g[d, b], coordinates[c])
        - sp.diff(g[b, c], coordinates[d])) for d in range(4)) / 2)


gamma = {(a, b, c): connection(a, b, c)
         for a in range(4) for b in range(4) for c in range(4)}


def riemann_up(a, b, c, d):
    return sp.simplify(
        sp.diff(gamma[a, d, b], coordinates[c])
        - sp.diff(gamma[a, c, b], coordinates[d])
        + sum(gamma[a, c, e]*gamma[e, d, b]
              - gamma[a, d, e]*gamma[e, c, b] for e in range(4)))


def curvature():
    ricci = sp.Matrix(4, 4, lambda b, d: sum(
        riemann_up(a, b, a, d) for a in range(4)))
    assert ricci == sp.zeros(4)
    origin = {x: 0, y: 0}
    assert all(value.subs(origin) == 0 for value in gamma.values())
    tangent = sp.Matrix([1/sp.sqrt(2), 1/sp.sqrt(2), 0, 0])
    spatial = [sp.Matrix([0, 0, 1, 0]), sp.Matrix([0, 0, 0, 1]),
               sp.Matrix([1/sp.sqrt(2), -1/sp.sqrt(2), 0, 0])]
    assert (tangent.T*g*tangent)[0].subs(origin) == -1

    def lower(a, b, c, d):
        return sum(g[a, e]*riemann_up(e, b, c, d) for e in range(4)).subs(origin)

    electric = sp.Matrix(3, 3, lambda i, j: sp.simplify(sum(
        spatial[i][a]*tangent[b]*spatial[j][c]*tangent[d]*lower(a, b, c, d)
        for a in range(4) for b in range(4) for c in range(4) for d in range(4)
        if spatial[i][a]*tangent[b]*spatial[j][c]*tangent[d] != 0)))
    assert electric == sp.diag(-omega**2, omega**2, 0)
    return dict(ricci_zero=True, parallel_frame_on_axis=True,
                electric_tidal_matrix=str(electric))


def clock():
    z = sp.symbols("z", real=True)
    tau, t0 = sp.symbols("tau t0", positive=True)
    coefficients = [(0, 0, 0), (sp.Rational(2, 5), -sp.Rational(1, 5), sp.Rational(3, 10)),
                    (-sp.Rational(1, 10), sp.Rational(3, 10), -sp.Rational(1, 10))]
    factors = [sp.diag(sp.cosh(z)+a*sp.sinh(z),
                       sp.cos(z)+b*sp.sin(z), 1+c*z)
               for a, b, c in coefficients]
    acceleration = sp.diag(1, -1, 0)
    for matrix in factors:
        assert (matrix.diff(z, 2) - acceleration*matrix).applyfunc(sp.simplify) == sp.zeros(3)
    reference_norms = []
    for i, j in ((0, 1), (0, 2), (1, 2)):
        bracket = factors[i].T*factors[j].diff(z)-factors[i].diff(z).T*factors[j]
        expected = sp.diag(*(coefficients[j][k]-coefficients[i][k] for k in range(3)))
        assert (bracket-expected).applyfunc(sp.simplify) == sp.zeros(3)
        reference_norms.append(str(sp.trace(expected.T*expected)))
    # tau = t0*(exp(label)-1), so three labels give these proper times exactly.
    time_landmarks = [t0*(sp.Rational(k, 6)-1) for k in (7, 8, 9)]
    ratio = sp.simplify((time_landmarks[2]-time_landmarks[1]) /
                        (time_landmarks[1]-time_landmarks[0]))
    assert ratio == 1
    assert sp.Rational(31, 40)**2 > sp.Rational(3, 5)
    assert sp.Rational(9, 4)*(sp.Rational(3, 4)**2 + sp.Rational(27, 31)**2 + sp.Rational(3, 10)**2) < sp.Rational(9, 5)**2
    return dict(reference_squared_norms=reference_norms,
                recovered_relative_lapse="exp(label)",
                time_landmark_ratio=str(ratio),
                dimensionless_proper_time_interval=[0, 0.5])


if __name__ == "__main__":
    result = dict(metric=curvature(), covariance_clock=clock())
    text = json.dumps(result, indent=2)
    Path(__file__).with_name("plane_wave_results.json").write_text(text + "\n")
    print(text)
